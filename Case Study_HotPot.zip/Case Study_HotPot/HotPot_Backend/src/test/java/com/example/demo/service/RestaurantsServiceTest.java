package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.*;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Restaurants;
import com.example.demo.repo.RestaurantsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.*;

public class RestaurantsServiceTest {

    @InjectMocks
    private RestaurantsService restaurantsService;

    @Mock
    private RestaurantsRepository repo;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddRestaurant() {
        Restaurants r = new Restaurants();
        r.setName("Test Restaurant");

        String result = restaurantsService.add(r);

        verify(repo, times(1)).save(r);
        assertEquals("Restaurant Added", result);
    }

    @Test
    public void testShowAllRestaurants() {
        List<Restaurants> list = Arrays.asList(new Restaurants(), new Restaurants());
        when(repo.findAll()).thenReturn(list);

        List<Restaurants> result = restaurantsService.showAll();

        assertEquals(2, result.size());
    }

    @Test
    public void testShowByName() {
        String name = "Burger Place";
        List<Restaurants> list = List.of(new Restaurants());
        when(repo.findByName(name)).thenReturn(list);

        List<Restaurants> result = restaurantsService.showByName(name);
        assertEquals(1, result.size());
    }

    @Test
    public void testShowByNameLocation_Success() {
        String name = "Food Corner";
        String location = "Chennai";
        Restaurants rest = new Restaurants();
        when(repo.findByNameAndLocation(name, location)).thenReturn(rest);

        ResponseEntity<Restaurants> result = restaurantsService.showByNameLocation(name, location);

        assertEquals(200, result.getStatusCodeValue());
        assertEquals(rest, result.getBody());
    }

    @Test
    public void testShowByNameLocation_NotFound() {
        when(repo.findByNameAndLocation("name", "loc")).thenReturn(null);

        assertThrows(ResourceNotFoundException.class, () -> {
            restaurantsService.showByNameLocation("name", "loc");
        });
    }


    @Test
    public void testShowByCity() {
        List<Restaurants> list = List.of(new Restaurants());
        when(repo.findByLocationIgnoreCase("Chennai")).thenReturn(list);

        List<Restaurants> result = restaurantsService.showByCity("Chennai");

        assertEquals(1, result.size());
    }

    @Test
    public void testDeleteRestaurant_Success() {
        int id = 1;
        when(repo.existsById(id)).thenReturn(true);

        String result = restaurantsService.delete(id);

        verify(repo).deleteById(id);
        assertEquals("Deleted", result);
    }

    @Test
    public void testDeleteRestaurant_NotFound() {
        when(repo.existsById(999)).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> {
            restaurantsService.delete(999);
        });
    }

    @Test
    public void testGetByUsername() {
        Restaurants r = new Restaurants();
        r.setUsername("testUser");
        when(repo.findByUsername("testUser")).thenReturn(r);

        Restaurants result = restaurantsService.getByUsername("testUser");

        assertEquals("testUser", result.getUsername());
    }

    @Test
    public void testLoadUserByUsername_Success() {
        Restaurants r = new Restaurants();
        r.setUsername("admin");
        r.setPassword("secret");
        when(repo.findByUsername("admin")).thenReturn(r);

        UserDetails userDetails = restaurantsService.loadUserByUsername("admin");

        assertEquals("admin", userDetails.getUsername());
        assertEquals("secret", userDetails.getPassword());
    }

    @Test
    public void testLoadUserByUsername_NotFound() {
        when(repo.findByUsername("nouser")).thenReturn(null);

        assertThrows(UsernameNotFoundException.class, () -> {
            restaurantsService.loadUserByUsername("nouser");
        });
    }
}

