package com.example.demo.service;

import com.example.demo.exception.ResourceNotFoundException;

import com.example.demo.model.OrderStatus;
import com.example.demo.model.Orders;
import com.example.demo.model.WalSource;
import com.example.demo.repo.OrdersRepository;
import com.example.demo.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrdersService {

    @Autowired
    private OrdersRepository ordersRepository;

    @Autowired
    private WalletService walletService;

    public Orders placeOrder(Orders order) {
    	if (order.getOrdStatus() == null) {
            order.setOrdStatus(OrderStatus.PENDING); 
        }
        return ordersRepository.save(order);
    }

    public List<Orders> getAllOrders() {
        return ordersRepository.findAll();
    }

    public ResponseEntity<Orders> getOrderById(int id) {
        Orders order = ordersRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + id));
        return ResponseEntity.ok(order);
    }

    public List<Orders> getOrdersByCustomerId(int cusId) {
        return ordersRepository.findByCusId(cusId);
    }
    public List<Orders> getOrdersByRestaurantId(int restaurantId) {
        return ordersRepository.findByRestaurantId(restaurantId);
    }

    public String updateStatusByRestaurant(int id, String newStatus) {
        Orders order = ordersRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + id));
        order.setOrdStatus(OrderStatus.valueOf(newStatus.toUpperCase()));
        ordersRepository.save(order);
        return "Order " + newStatus.toUpperCase();
    }

    public List<Orders> getOrdersByAdminId(int admId) {
        return ordersRepository.findByAdmId(admId);
    }

    public Orders updateOrderStatus(int id, Orders updatedOrder) {
        Orders order = ordersRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + id));
        order.setOrdStatus(updatedOrder.getOrdStatus());
        order.setOrdComments(updatedOrder.getOrdComments());
        return ordersRepository.save(order);
    }

    public ResponseEntity<Orders> updateOrderStatus(int id, String newStatus, String comments) {
        Orders order = ordersRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + id));
        order.setOrdStatus(OrderStatus.valueOf(newStatus.toUpperCase()));
        order.setOrdComments(comments);
        Orders updated = ordersRepository.save(order);
        return ResponseEntity.ok(updated);
    }

    public void deleteOrder(int id) {
        if (!ordersRepository.existsById(id)) {
            throw new ResourceNotFoundException("Cannot delete. Order ID not found: " + id);
        }
        ordersRepository.deleteById(id);
    }

    public ResponseEntity<String> cancelOrder(int orderId) {
        Orders order = ordersRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + orderId));
        if (order.getOrdStatus() == OrderStatus.CANCELLED) {
            return ResponseEntity.badRequest().body("Order is already cancelled.");
        }
        order.setOrdStatus(OrderStatus.CANCELLED);
        ordersRepository.save(order);

        double penalty = order.getOrdBillamount() * 0.10;
        try {
            WalSource walSource;
            try {
                String rawSource = order.getWalSource();
                System.out.println("Order walSource value: '" + rawSource + "'");
                walSource = WalSource.valueOf(rawSource.trim().toUpperCase());
            } catch (Exception e) {
                return ResponseEntity.badRequest().body("Invalid wallet source for this order. Must be one of: PAYTM, CREDIT_CARD, DEBIT_CARD.");
            }
            walletService.deductFromWallet(order.getCusId(), walSource, penalty);
        } catch (IllegalArgumentException | ResourceNotFoundException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }

        String message = String.format("Order cancelled. 10%% (%.2f) has been deducted from your wallet.", penalty);
        return ResponseEntity.ok(message);
    }
}

