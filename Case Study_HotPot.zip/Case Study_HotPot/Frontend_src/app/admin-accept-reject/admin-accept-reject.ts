import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Orders } from '../orders';
import { OrdersService } from '../orders.service';

@Component({
  selector: 'app-admin-accept-reject',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-accept-reject.html',
  styleUrls: ['./admin-accept-reject.css'],
})
export class AdminAcceptRejectComponent {
  admId: number = parseInt(localStorage.getItem('admId') || '0');
  orders: Orders[] = [];
  result: string = '';
  comments: string = '';

  constructor(private _orderService: OrdersService) {
    if (!this.admId || isNaN(this.admId)) {
      console.error('Admin ID is invalid or missing in localStorage.');
      return;
    }

    this._orderService.getOrdersByAdmin(this.admId).subscribe((data) => {
      this.orders = data.filter((o) => o.ordStatus === 'PENDING');
    });
  }

  yes(ordId: number): void {
    this._orderService
      .updateOrderStatus(ordId, 'ACCEPTED', this.comments)
      .subscribe(() => {
        alert('Order accepted.');
        this.refreshOrders();
      });
  }

  no(ordId: number): void {
    this._orderService
      .updateOrderStatus(ordId, 'DENIED', this.comments) // ✅ changed 'REJECTED' to 'DENIED'
      .subscribe(() => {
        alert('Order denied.');
        this.refreshOrders();
      });
  }

  refreshOrders(): void {
    this._orderService.getOrdersByAdmin(this.admId).subscribe((data) => {
      this.orders = data.filter((o) => o.ordStatus === 'PENDING');
    });
  }
}
