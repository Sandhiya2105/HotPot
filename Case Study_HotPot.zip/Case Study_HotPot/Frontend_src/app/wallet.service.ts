import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Wallet } from './wallet';

@Injectable({ providedIn: 'root' })
export class WalletService {
  private baseUrl = 'http://localhost:9090';

  constructor(private http: HttpClient) {}

  getCustomerWallets(custId: number): Observable<Wallet[]> {
    return this.http.get<Wallet[]>(
      `${this.baseUrl}/showCustomerWallets/${custId}`
    );
  }

  getWalletById(walletId: number): Observable<Wallet> {
    return this.http.get<Wallet>(`${this.baseUrl}/showWalletById/${walletId}`);
  }
  showCustomerWallet(custId: number): Observable<Wallet[]> {
    return this.http.get<Wallet[]>(
      this.baseUrl + '/showCustomerWallets/' + custId
    );
  }

  addWallet(wallet: Wallet): Observable<string> {
    return this.http.post(this.baseUrl + '/addWallet', wallet, {
      responseType: 'text',
    });
  }
}
