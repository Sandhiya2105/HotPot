import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Orders } from './orders';

@Injectable({ providedIn: 'root' })
export class OrdersService {
  private baseUrl = 'http://localhost:9090/orders';

  constructor(private http: HttpClient) {}

  placeOrder(order: Orders): Observable<string> {
    return this.http.post(this.baseUrl + '/place', order, {
      responseType: 'text',
    });
  }

  getAllOrders(): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/all');
  }

  getOrdersByCustomer(custId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/customer/' + custId);
  }

  getOrdersByAdmin(admId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/admin/' + admId);
  }

  getOrdersByCustomerId(custId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/customer/' + custId);
  }

  getPendingOrdersByCustomerId(custId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/customer/' + custId); // replace if separate endpoint exists
  }

  // ✅ ADD THIS: Get orders by restaurantId
  getOrdersByRestaurant(restaurantId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(
      `${this.baseUrl}/restaurant/${restaurantId}`
    );
  }

  // ✅ Update status only (for restaurant accept/reject)
  updateOrderStatus(
    id: number,
    status: string,
    comments: string
  ): Observable<Orders> {
    return this.http.put<Orders>(
      this.baseUrl + `/decision/${id}?status=${status}&comments=${comments}`,
      {}
    );
  }

  // If you still need admin's comment-based decision, keep this too
  updateOrderStatusWithComments(
    id: number,
    status: string,
    comments: string
  ): Observable<Orders> {
    return this.http.put<Orders>(
      this.baseUrl + `/decision/${id}?status=${status}&comments=${comments}`,
      {}
    );
  }

  // Cancel an order by ID
  cancelOrder(id: number): Observable<string> {
    return this.http.put(this.baseUrl + '/cancel/' + id, {}, { responseType: 'text' });
  }
}
