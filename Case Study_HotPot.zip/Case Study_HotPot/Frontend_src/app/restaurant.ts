export class Restaurant {
  restaurantId?: number;
  name?: string;
  location?: string;
  contactNumber?: string;
  email?: string;
  username: string = '';
  password: string = '';
}
