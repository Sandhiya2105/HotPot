import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Admin } from './admin';
import { Orders } from './orders';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root',
})
export class AdminService {
  private baseUrl = 'http://localhost:9090';

  constructor(private http: HttpClient) {}

  loginAdmin(admin: Admin): Observable<string> {
    return this.http.post(
      this.baseUrl + '/auth/login?role=admin',
      {
        username: admin.admUsername,
        password: admin.admPassword,
      },
      { responseType: 'text' }
    );
  }

  getAllOrders(): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/orders/all');
  }

  getAllMenu(): Observable<Menu[]> {
    return this.http.get<Menu[]>(this.baseUrl + '/showMenu');
  }

  getPendingOrders(): Observable<Orders[]> {
    return this.http.get<Orders[]>(this.baseUrl + '/orders/all');
  }

  getOrdersByAdmin(admId: number): Observable<Orders[]> {
    return this.http.get<Orders[]>(`${this.baseUrl}/orders/admin/${admId}`);
  }

  getAllAdmins(): Observable<Admin[]> {
    return this.http.get<Admin[]>(`${this.baseUrl}/admin/all`);
  }

  updateOrderStatus(
    orderId: number,
    status: string,
    comments: string
  ): Observable<any> {
    return this.http.put(
      `${this.baseUrl}/orders/decision/${orderId}?status=${status}&comments=${comments}`,
      {},
      { responseType: 'text' }
    );
  }

  getAdminById(admId: number): Observable<Admin> {
    return this.http.get<Admin>(`${this.baseUrl}/admin/${admId}`);
  }

  getAdminByUsername(username: string): Observable<Admin> {
    return this.http.get<Admin>(
      `${this.baseUrl}/admin/searchByUserName/${username}`
    );
  }
}
