import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CartService {
  private baseUrl = 'http://localhost:9090/cart';

  constructor(private http: HttpClient) {}

  addToCart(cart: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/add`, cart);
  }

  getCartByCustomerId(cusId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/customer/${cusId}`);
  }

  removeFromCart(cartId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/remove/${cartId}`);
  }

  getAll(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/all`);
  }
}
