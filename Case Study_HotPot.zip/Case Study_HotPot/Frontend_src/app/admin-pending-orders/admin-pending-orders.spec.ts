import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPendingOrders } from './admin-pending-orders';

describe('AdminPendingOrders', () => {
  let component: AdminPendingOrders;
  let fixture: ComponentFixture<AdminPendingOrders>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminPendingOrders]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminPendingOrders);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
