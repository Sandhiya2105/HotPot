import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Orders } from '../orders';
import { AdminService } from '../admin-service';

@Component({
  selector: 'app-admin-pending-orders',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-pending-orders.html',
  styleUrls: ['./admin-pending-orders.css'],
})
export class AdminPendingOrdersComponent {
  admId: number = parseInt(localStorage.getItem('admId') || '0');
  orders: Orders[] = [];

  constructor(private _adminService: AdminService) {
    if (!this.admId || isNaN(this.admId)) {
      console.error('Admin ID is invalid or missing in localStorage.');
      return;
    }

    this._adminService
      .getOrdersByAdmin(this.admId)
      .subscribe((data: Orders[]) => {
        console.log('All orders for admin:', data); // ✅ for debugging

        // ✅ Case-insensitive status check
        this.orders = data.filter(
          (o) => o.ordStatus?.toUpperCase() === 'PENDING'
        );
      });
  }
}
