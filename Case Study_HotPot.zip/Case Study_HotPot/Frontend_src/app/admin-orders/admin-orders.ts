import { Component, OnInit } from '@angular/core';
import { Orders } from '../orders';
import { AdminService } from '../admin-service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-admin-orders',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-orders.html',
  styleUrls: ['./admin-orders.css'],
})
export class AdminOrdersComponent implements OnInit {
  orders: Orders[] = [];

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.adminService.getAllOrders().subscribe((data) => (this.orders = data));
  }
}
