import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { Menu } from '../menu';
import { CartService } from '../cart-service';
import { MenuService } from '../menu.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './cart.html',
  styleUrls: ['./cart.css'],
})
export class CartComponent {
  customerId: number = parseInt(localStorage.getItem('cid') || '0');
  menuList: Menu[] = [];
  cartList: any[] = [];
  result: string = '';

  cart = {
    cusId: this.customerId,
    menId: '',
    quantity: 1,
  };

  constructor(
    private cartService: CartService,
    private menuService: MenuService
  ) {
    this.loadCart();
    this.menuService.showMenu().subscribe((data) => (this.menuList = data));
  }

  loadCart() {
    this.cartService.getCartByCustomerId(this.customerId).subscribe((data) => {
      this.cartList = data;
    });
  }

  addToCart(): void {
    if (this.cart.cusId && this.cart.menId && this.cart.quantity > 0) {
      console.log('Sending Payload:', this.cart);

      this.cartService.addToCart(this.cart).subscribe({
        next: () => {
          this.result = 'Item added to cart!';
          this.loadCart(); // reload
        },
        error: (err) => {
          console.error('Error adding to cart:', err);
          this.result = 'Failed to add to cart.';
        },
      });
    }
  }

  removeFromCart(cartId: number): void {
    this.cartService.removeFromCart(cartId).subscribe(() => {
      alert('Item removed from cart');
      this.loadCart();
    });
  }
}
