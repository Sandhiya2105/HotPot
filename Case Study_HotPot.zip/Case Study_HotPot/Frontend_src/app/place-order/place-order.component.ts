import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { Menu } from '../menu';
import { Admin } from '../admin';
import { Orders } from '../orders';
import { Wallet } from '../wallet';
import { Restaurant } from '../restaurant';

import { MenuService } from '../menu.service';
import { AdminService } from '../admin-service';
import { WalletService } from '../wallet.service';
import { OrdersService } from '../orders.service';
import { RestaurantService } from '../restaurant-service';

@Component({
  selector: 'app-place-order',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './place-order.component.html',
  styleUrl: './place-order.component.css',
})
export class PlaceOrderComponent {
  menu: Menu[] = [];
  filteredMenu: Menu[] = [];
  admin: Admin[] = [];
  orders: Orders = new Orders();
  wallet: Wallet[] = [];
  restaurants: Restaurant[] = [];
  result: any;
  isRestaurantSelected: boolean = false;
  totalAmount: number = 0;

  constructor(
    private _menuService: MenuService,
    private _adminService: AdminService,
    private _walletService: WalletService,
    private _orderService: OrdersService,
    private _restaurantService: RestaurantService
  ) {
    this.orders.cusId = parseInt(localStorage.getItem('cid') || '0');

    this._menuService.showMenu().subscribe((x) => {
      this.menu = x;
      this.filteredMenu = [];
    });

    this._adminService.getAllAdmins().subscribe((x) => {
      this.admin = x;
    });

    this._walletService.showCustomerWallet(this.orders.cusId).subscribe((x) => {
      this.wallet = x;
    });

    this._restaurantService.showAllRestaurants().subscribe((x) => {
      this.restaurants = x;
    });
  }

  onRestaurantSelect() {
    if (this.orders.restaurantId) {
      // Filter menu items by selected restaurant
      this.filteredMenu = this.menu.filter(
        (item) => item.restaurant?.restaurantId === +this.orders.restaurantId
      );
      this.isRestaurantSelected = true;
      // Reset menu selection when restaurant changes
      this.orders.menId = undefined;
      this.totalAmount = 0;
    } else {
      // Show no menu items if no restaurant is selected
      this.filteredMenu = [];
      this.isRestaurantSelected = false;
      this.totalAmount = 0;
    }
  }

  onMenuSelect() {
    const selected = this.filteredMenu.find((m) => m.menId === +this.orders.menId);
    if (selected && selected.restaurant) {
      this.orders.restaurantId = selected.restaurant.restaurantId;
      this.calculateTotal();
    }
  }

  onQuantityChange() {
    this.calculateTotal();
  }

  calculateTotal() {
    if (this.orders.menId && this.orders.ordQuantity) {
      const selected = this.filteredMenu.find((m) => m.menId === +this.orders.menId);
      if (selected && selected.menPrice) {
        this.totalAmount = selected.menPrice * +this.orders.ordQuantity;
      }
    } else {
      this.totalAmount = 0;
    }
  }

  placeOrder(orderForm: NgForm) {
    if (orderForm.invalid) {
      alert('Please fill all required fields correctly.');
      return;
    }

    if (!this.orders.restaurantId) {
      alert('Please select a restaurant first.');
      return;
    }

    if (!this.orders.menId) {
      alert('Please select a menu item.');
      return;
    }

    this.orders.ordDate = new Date();

    const selected = this.filteredMenu.find((m) => +m.menId === +this.orders.menId);
    if (selected && selected.restaurant) {
      this.orders.restaurantId = selected.restaurant.restaurantId;
      this.orders.ordBillamount = selected.menPrice * +this.orders.ordQuantity;
    }

    // Coerce all IDs and numeric fields
    this.orders.menId = +this.orders.menId;
    this.orders.admId = +this.orders.admId;
    this.orders.ordQuantity = +this.orders.ordQuantity;
    this.orders.restaurantId = +this.orders.restaurantId;

    console.log('Order Payload: ', this.orders);

    this._orderService.placeOrder(this.orders).subscribe({
      next: (res: any) => {
        this.result =
          typeof res === 'string'
            ? res
            : res?.message ?? 'Order placed successfully';
        alert(this.result);
        // Reset form after successful order
        if (this.result.includes('successfully')) {
          orderForm.resetForm();
          this.orders = new Orders();
          this.orders.cusId = parseInt(localStorage.getItem('cid') || '0');
          this.filteredMenu = [];
          this.isRestaurantSelected = false;
          this.totalAmount = 0;
        }
      },
      error: (err) => {
        console.error('Order failed', err);
        alert('Something went wrong while placing the order. Please try again.');
      },
    });
  }
}

