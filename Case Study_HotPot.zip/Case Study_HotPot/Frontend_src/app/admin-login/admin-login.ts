import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin-service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-login.html',
  styleUrls: ['./admin-login.css'],
})
export class AdminLoginComponent {
  admin: Admin = new Admin();
  isValid: boolean = false;
  message: string = '';

  constructor(private adminService: AdminService, private router: Router) {}

  login(loginForm: NgForm): void {
    this.isValid = false;
    if (loginForm.invalid) return;

    this.isValid = true;

    this.adminService.loginAdmin(this.admin).subscribe({
      next: (response) => {
        // Token received
        // Now fetch admin details using username to get admId
        this.adminService
          .getAdminByUsername(this.admin.admUsername)
          .subscribe((adminData) => {
            localStorage.setItem('admId', adminData.admId.toString());
            this.router.navigate(['adminMenu']);
          });
      },
      error: (err) => {
        this.message = 'Invalid credentials or login error.';
        console.error(err);
      },
    });
  }
}
