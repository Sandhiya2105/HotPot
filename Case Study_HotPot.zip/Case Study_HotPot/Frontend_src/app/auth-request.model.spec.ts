import { AuthRequestModel } from './auth-request.model';

describe('AuthRequestModel', () => {
  it('should create an instance', () => {
    expect(new AuthRequestModel()).toBeTruthy();
  });
});
