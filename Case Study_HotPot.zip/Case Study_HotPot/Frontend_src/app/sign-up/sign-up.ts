import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-sign-up',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './sign-up.html',
  styleUrl: './sign-up.css',
})
export class SignUpComponent {
  customer: Customer = new Customer();
  message: string = '';
  isValid: boolean = false;

  constructor(private customerService: CustomerService, private router: Router) {}

  register(form: NgForm): void {
    this.isValid = false;
    if (form.invalid) return;
    this.isValid = true;
    this.customerService.registerCustomer(this.customer).subscribe({
      next: (res) => {
        this.message = 'Registration successful! Please login.';
        setTimeout(() => this.router.navigate(['/customerLogin']), 1500);
      },
      error: (err) => {
        this.message = 'Registration failed. Try again.';
      },
    });
  }
}
