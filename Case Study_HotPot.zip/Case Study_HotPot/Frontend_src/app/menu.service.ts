import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
  private baseUrl = 'http://localhost:9090';

  constructor(private _http: HttpClient) {}

  // ✅ Add Menu (Missing method earlier)
  addMenu(menu: Menu): Observable<any> {
    return this._http.post('http://localhost:9090/menu/addMenu', menu, {
      responseType: 'text',
    });
  }

  // Show all menu
  showMenu(): Observable<Menu[]> {
    return this._http.get<Menu[]>(`${this.baseUrl}/showMenu`);
  }

  // Search menu by ID
  searchById(id: number): Observable<Menu> {
    return this._http.get<Menu>(`${this.baseUrl}/searchMenu/${id}`);
  }

  // Search menu by restaurant ID
  searchByRestaurantId(restaurantId: number): Observable<Menu[]> {
    return this._http.get<Menu[]>(
      `${this.baseUrl}/searchByRestaurantId/${restaurantId}`
    );
  }

  // Delete menu by ID
  deleteMenu(menuId: number): Observable<string> {
    return this._http.delete(`${this.baseUrl}/deleteMenu/${menuId}`, {
      responseType: 'text',
    });
  }
}
