import { Component } from '@angular/core';
import { MenuService } from '../menu.service';
import { Menu } from '../menu';
import { Restaurant } from '../restaurant';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-add-menu',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './add-menu.html',
  styleUrls: ['./add-menu.css'],
})
export class AddMenuComponent {
  menu: Menu = new Menu();
  result: string = '';
  categories: string[] = [
    'Breakfast',
    'Lunch',
    'Dinner',
    'Starter',
    'Snack',
    'Main Course',
  ];

  constructor(private menuService: MenuService) {}

  add(): void {
    const restId = localStorage.getItem('restaurantId');
    if (restId) {
      this.menu.restaurant = new Restaurant();
      this.menu.restaurant.restaurantId = +restId;

      console.log('Payload:', this.menu); // Debug
      this.menuService.addMenu(this.menu).subscribe({
        next: (res) => (this.result = res),
        error: (err) => {
          console.error('Failed to add menu:', err);
          this.result = 'Failed to add menu';
        },
      });
    }
  }
}
