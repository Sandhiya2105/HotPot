import { Component, OnInit } from '@angular/core';

import { Restaurant } from '../restaurant';
import { RestaurantService } from '../restaurant-service';

@Component({
  selector: 'app-restaurant-info',
  templateUrl: './restaurant-info.html',
  styleUrl: './restaurant-info.css',
})
export class RestaurantInfoComponent implements OnInit {
  restaurant: Restaurant = new Restaurant();

  constructor(private service: RestaurantService) {}

  ngOnInit(): void {
    const restId = localStorage.getItem('restaurantId');
    if (restId) {
      this.service
        .getRestaurantById(+restId)
        .subscribe((data) => (this.restaurant = data));
    }
  }
}
