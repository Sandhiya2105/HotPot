import { Restaurant } from './restaurant';

export class Menu {
  menId?: number;
  menItem?: string;
  menPrice?: number;
  menSpeciality?: string;
  menCategories?: string;
  restaurant!: Restaurant; // ✅ This ensures restaurant is expected and required
}
