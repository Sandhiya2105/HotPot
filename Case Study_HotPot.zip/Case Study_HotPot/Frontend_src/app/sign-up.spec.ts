import { SignUp } from './sign-up';

describe('SignUp', () => {
  it('should create an instance', () => {
    expect(new SignUp()).toBeTruthy();
  });
});
