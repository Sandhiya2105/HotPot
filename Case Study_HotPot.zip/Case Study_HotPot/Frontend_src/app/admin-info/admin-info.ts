import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin-service';

@Component({
  selector: 'app-admin-info',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-info.html',
  styleUrls: ['./admin-info.css'],
})
export class AdminInfoComponent {
  admin: Admin = new Admin();
  admId: number;

  constructor(private _adminService: AdminService) {
    this.admId = parseInt(localStorage.getItem('admId') || '0');

    if (!this.admId || isNaN(this.admId)) {
      console.error('Admin ID is invalid or missing in localStorage.');
      return;
    }

    this._adminService.getAdminById(this.admId).subscribe((data) => {
      this.admin = data;
    });
  }
}
