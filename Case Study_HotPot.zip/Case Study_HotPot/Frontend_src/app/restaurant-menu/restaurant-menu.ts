import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-restaurant-menu',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './restaurant-menu.html',
  styleUrl: './restaurant-menu.css',
})
export class RestaurantMenuComponent {
  restaurantName: string = '';

  ngOnInit(): void {
    this.restaurantName =
      localStorage.getItem('restaurantName') || 'Restaurant';
  }
}
