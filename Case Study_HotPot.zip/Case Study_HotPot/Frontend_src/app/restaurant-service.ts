import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Restaurant } from './restaurant';

@Injectable({ providedIn: 'root' })
export class RestaurantService {
  private baseUrl = 'http://localhost:9090';

  constructor(private http: HttpClient) {}

  // Add new restaurant
  addRestaurant(restaurant: Restaurant): Observable<string> {
    return this.http.post(this.baseUrl + '/restaurant/add', restaurant, {
      responseType: 'text',
    });
  }

  // Fetch all restaurants
  showAllRestaurants(): Observable<Restaurant[]> {
    return this.http.get<Restaurant[]>(this.baseUrl + '/restaurant/all');
  }

  // Fetch restaurant by city
  getRestaurantByCity(city: string): Observable<Restaurant[]> {
    return this.http.get<Restaurant[]>(
      this.baseUrl + '/restaurant/byCity/' + city
    );
  }

  // Fetch by ID
  getRestaurantById(id: number): Observable<Restaurant> {
    return this.http.get<Restaurant>(this.baseUrl + '/restaurant/' + id);
  }

  // Delete restaurant
  deleteRestaurant(id: number): Observable<string> {
    return this.http.delete(this.baseUrl + '/restaurant/delete/' + id, {
      responseType: 'text',
    });
  }

  // ✅ Login restaurant (token returned as plain text)
  loginRestaurant(restaurant: Restaurant): Observable<string> {
    return this.http.post(
      this.baseUrl + '/auth/login?role=restaurant',
      {
        username: restaurant.username,
        password: restaurant.password,
      },
      { responseType: 'text' }
    );
  }

  // ✅ Fetch restaurant info by username (to retrieve restaurantId)
  getByUsername(username: string): Observable<Restaurant> {
    return this.http.get<Restaurant>(
      this.baseUrl + '/restaurant/byUsername/' + username
    );
  }
}
