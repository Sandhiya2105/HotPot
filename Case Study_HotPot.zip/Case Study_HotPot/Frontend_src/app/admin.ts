export class Admin {
  admId?: number;
  admName?: string;
  admUsername: string = '';
  admPassword: string = '';
  admEmail?: string;
}
