import { Component, OnInit } from '@angular/core';
import { OrdersService } from '../orders.service';
import { Orders } from '../orders';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-view-orders',
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './view-orders.html',
  styleUrl: './view-orders.css',
})
export class ViewOrdersComponent implements OnInit {
  orders: Orders[] = [];

  constructor(private orderService: OrdersService) {}

  ngOnInit(): void {
    const restId = localStorage.getItem('restaurantId');
    if (restId) {
      this.orderService
        .getOrdersByRestaurant(+restId)
        .subscribe((data) => (this.orders = data));
    }
  }

  updateStatus(ordId: number, status: string): void {
    const comments =
      status === 'ACCEPTED'
        ? 'Accepted by restaurant'
        : 'Rejected by restaurant';

    this.orderService
      .updateOrderStatus(ordId, status, comments)
      .subscribe(() => alert(`Order ${status}`));
  }
}
