import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Restaurant } from '../restaurant';
import { RestaurantService } from '../restaurant-service';

@Component({
  selector: 'app-restaurant-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './restaurant-login.html',
  styleUrl: './restaurant-login.css',
})
export class RestaurantLoginComponent {
  restaurant: Restaurant = new Restaurant();
  message: string = '';
  isValid: boolean = false;

  constructor(
    private restaurantService: RestaurantService,
    private router: Router
  ) {}

  login(loginForm: NgForm): void {
    this.isValid = false;
    if (loginForm.invalid) return;

    this.isValid = true;

    this.restaurantService.loginRestaurant(this.restaurant).subscribe({
      next: (token) => {
        // Store token (optional) and fetch restaurant info
        this.restaurantService
          .getByUsername(this.restaurant.username)
          .subscribe((res) => {
            localStorage.setItem(
              'restaurantId',
              res.restaurantId?.toString() || ''
            );
            localStorage.setItem('restaurantName', res.name || '');
            this.router.navigate(['restaurantMenu']);
          });
      },
      error: (err) => {
        console.error('Login failed', err);
        this.message = 'Invalid credentials or error during login.';
      },
    });
  }
}
