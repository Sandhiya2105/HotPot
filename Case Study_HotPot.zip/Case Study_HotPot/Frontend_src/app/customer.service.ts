import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { AuthRequestModel } from './auth-request.model';

@Injectable({ providedIn: 'root' })
export class CustomerService {
  private baseUrl = 'http://localhost:9090';

  constructor(private http: HttpClient) {}

  registerCustomer(customer: Customer): Observable<string> {
    return this.http.post(this.baseUrl + '/addCustomer', customer, {
      responseType: 'text',
    });
  }

  loginCustomer(request: AuthRequestModel): Observable<string> {
    return this.http.post(
      this.baseUrl + '/auth/login?role=customer',
      {
        username: request.username,
        password: request.password,
      },
      { responseType: 'text' }
    );
  }

  searchCustomer(custId: number): Observable<Customer> {
    return this.http.get<Customer>(this.baseUrl + '/searchCustomer/' + custId);
  }

  getAllCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.baseUrl + '/showCustomer');
  }
  searchByUserName(username: string): Observable<Customer> {
    return this.http.get<Customer>(
      this.baseUrl + '/searchByUserName/' + username
    );
  }
}
