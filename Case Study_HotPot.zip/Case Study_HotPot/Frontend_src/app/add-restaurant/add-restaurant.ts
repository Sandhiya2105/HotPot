import { Component } from '@angular/core';
import { NgForm, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { Restaurant } from '../restaurant';
import { RestaurantService } from '../restaurant-service';

@Component({
  selector: 'app-add-restaurant',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './add-restaurant.html',
  styleUrls: ['./add-restaurant.css'],
})
export class AddRestaurantComponent {
  restaurant: Restaurant = new Restaurant();
  result: string = '';

  constructor(private restaurantService: RestaurantService) {}

  addRestaurant(form: NgForm): void {
    if (form.invalid) return;
    this.restaurantService.addRestaurant(this.restaurant).subscribe({
      next: () => {
        this.result = 'Restaurant added successfully!';
        form.resetForm();
      },
      error: (err) => {
        console.error('Error:', err);
        this.result = 'Failed to add restaurant.';
      },
    });
  }
}
