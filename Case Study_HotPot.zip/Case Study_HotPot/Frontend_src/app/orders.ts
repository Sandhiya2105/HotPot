export class Orders {
  public ordId: number;
  public cusId: number;
  public admId: number;
  public restaurantId?: number;
  public walSource: string;
  public menId: number;
  public ordDate: Date;
  public ordQuantity: number;
  public ordBillamount: number;
  public ordStatus: string;
  public ordComments: string;
  constructor() {}
}
