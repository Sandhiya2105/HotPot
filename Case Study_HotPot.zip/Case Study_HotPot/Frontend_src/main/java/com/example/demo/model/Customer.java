package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "customer")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Customer {

    @Id
    @Column(name = "cus_id")
    private int cusId;

    @Column(name = "cus_name")
    private String cusName;

    @Column(name = "cus_phn_no")
    private String cusPhnNo;

    @Column(name = "cus_username")
    private String cusUsername;

    @Column(name = "cus_password")
    private String cusPassword;

    @Column(name = "cus_email")
    private String cusEmail;
    
 
    
}
