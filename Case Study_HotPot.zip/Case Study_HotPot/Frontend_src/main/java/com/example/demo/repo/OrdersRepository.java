package com.example.demo.repo;

import com.example.demo.model.Orders;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrdersRepository extends JpaRepository<Orders, Integer> {
    List<Orders> findByCusId(int cusId);
    List<Orders> findByAdmId(int admId);
    List<Orders> findByRestaurantId(int restaurantId);

}
