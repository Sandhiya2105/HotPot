package com.example.demo.service;

import com.example.demo.model.Cart;
import com.example.demo.repo.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    public Cart addToCart(Cart cart) {
        return cartRepository.save(cart);
    }

    public List<Cart> getCartByCustomerId(int cusId) {
        return cartRepository.findByCusId(cusId);
    }

    public void removeCartItem(int cartId) {
        cartRepository.deleteById(cartId);
    }

    public List<Cart> getAllCarts() {
        return cartRepository.findAll();
    }
}

