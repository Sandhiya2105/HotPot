package com.example.demo.model;

import lombok.*;
@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthRequest {
    private String username;
    private String password;
}

