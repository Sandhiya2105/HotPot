package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Restaurants;
import com.example.demo.service.RestaurantsService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/restaurant")
public class RestaurantsController {

    @Autowired
    private RestaurantsService service;

    @PostMapping("/add")
    public String add(@RequestBody Restaurants r) {
        return service.add(r);
    }

    @GetMapping("/all")
    public List<Restaurants> showAll() {
        return service.showAll();
    }

    @GetMapping("/byName/{name}")
    public List<Restaurants> showByName(@PathVariable String name) {
        return service.showByName(name);
    }

    @GetMapping("/byNameLocation/{name}/{location}")
    public ResponseEntity<Restaurants> showByNameLoc(@PathVariable String name, @PathVariable String location) {
        return service.showByNameLocation(name, location);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Restaurants> showById(@PathVariable int id) {
        return service.showById(id);
    }

    @GetMapping("/byCity/{location}")
    public List<Restaurants> showByCity(@PathVariable String location) {
        return service.showByCity(location);
    }

    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable int id) {
        return service.delete(id);
    }

    @GetMapping("/byUsername/{username}")
    public ResponseEntity<Restaurants> getByUsername(@PathVariable String username) {
        Restaurants r = service.getByUsername(username);
        if (r == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(r);
    }
}
