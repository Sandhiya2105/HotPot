package com.example.demo.controller;

import com.example.demo.config.JwtService;
import com.example.demo.model.AuthRequest;
import com.example.demo.service.AdminService;
import com.example.demo.service.CustomerService;
import com.example.demo.service.RestaurantsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AdminService adminService;

    @Autowired
    private CustomerService customerService;
    
    @Autowired
    private RestaurantsService restaurantService;

    @PostMapping("/login")
    public String login(@RequestBody AuthRequest request,
                        @RequestParam("role") String role) {

        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        UserDetails userDetails;
        if (role.equalsIgnoreCase("admin")) {
            userDetails = adminService.loadUserByUsername(request.getUsername());
        } else if (role.equalsIgnoreCase("customer")) {
            userDetails = customerService.loadUserByUsername(request.getUsername());
        } else if (role.equalsIgnoreCase("restaurant")) {
            userDetails = restaurantService.loadUserByUsername(request.getUsername());
        } else {
            throw new RuntimeException("Invalid role");
        }

        return jwtService.generateToken(userDetails.getUsername());
    }

}

