package com.example.demo.model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="Orders")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Orders {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int ordId;

	@Column(name = "cus_id")
	private int cusId;

	@Column(name = "restaurant_id")
	private int restaurantId;

	@Column(name = "adm_id")
	private int admId;

	@Column(name = "wal_source")
	private String walSource;

	@Column(name = "men_id")
	private int menId;

	@Column(name = "ord_date")
	private Date ordDate;

	@Column(name = "ord_quantity")
	private int ordQuantity;

	@Column(name = "ord_billamount")
	private double ordBillamount;

	@Enumerated(EnumType.STRING)
	@Column(name = "ord_status")
	private OrderStatus ordStatus;

	@Column(name = "ord_comments")
	private String ordComments;
}
