package com.example.demo.controller;

import com.example.demo.model.Cart;
import com.example.demo.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")

public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public Cart addToCart(@RequestBody Cart cart) {
        return cartService.addToCart(cart);
    }

    @GetMapping("/customer/{cusId}")
    public List<Cart> getCartByCustomer(@PathVariable int cusId) {
        return cartService.getCartByCustomerId(cusId);
    }

    @DeleteMapping("/remove/{cartId}")
    public void removeCart(@PathVariable int cartId) {
        cartService.removeCartItem(cartId);
    }

    @GetMapping("/all")
    public List<Cart> getAllCarts() {
        return cartService.getAllCarts();
    }
}


