package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotPotApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotPotApplication.class, args);
	}
}
