package com.example.demo.model;

import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "admin")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Admin {

    @Id
    @Column(name = "adm_id")
    private int admId;

    @Column(name = "adm_name")
    private String admName;

    @Column(name = "adm_phn_no")
    private String admPhnNo;

    @Column(name = "adm_username")
    private String admUsername;

    @Column(name = "adm_password")
    private String admPassword;

    @Column(name = "adm_email")
    private String admEmail;
}
