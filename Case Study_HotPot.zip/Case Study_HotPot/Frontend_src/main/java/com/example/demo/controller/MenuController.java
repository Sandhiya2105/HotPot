package com.example.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Menu;
import com.example.demo.service.MenuService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class MenuController {

    @Autowired
    private MenuService menuService;

    @GetMapping("/showMenu")
    public List<Menu> showMenu() {
        return menuService.showMenu();
    }

    @PostMapping("/addMenu") 
    public ResponseEntity<String> addMenu(@RequestBody Menu menu) {
        menuService.addMenu(menu); 
        return ResponseEntity.ok("Menu added successfully");
    }
    @GetMapping("/searchMenu/{id}")
    public ResponseEntity<Menu> searchById(@PathVariable int id) {
        return menuService.searchByMenuId(id);
    }

    @GetMapping("/searchByRestaurantId/{restaurantId}")
    public List<Menu> searchByRestaurant(@PathVariable int restaurantId) {
        return menuService.searchByRestaurantId(restaurantId);
    }

    @DeleteMapping("/deleteMenu/{menuId}")
    public String deleteMenu(@PathVariable int menuId) {
        return menuService.deleteMenu(menuId);
    }
}
