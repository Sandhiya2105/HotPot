package com.example.demo.service;

import com.example.demo.model.Admin;
import com.example.demo.repo.AdminRepository;
import com.example.demo.exception.ResourceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService implements UserDetailsService {

    @Autowired
    private AdminRepository adminRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Admin admin = adminRepo.findByAdmUsername(username);
        if (admin == null) {
            throw new UsernameNotFoundException("Admin not found");
        }
        return new User(admin.getAdmUsername(), admin.getAdmPassword(), List.of());
    }

   
    public Admin addAdmin(Admin admin) {
        return adminRepo.save(admin);
    }

    
    public List<Admin> getAllAdmins() {
        return adminRepo.findAll();
    }

   
    public ResponseEntity<Admin> getAdminById(int id) {
        Admin admin = adminRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Admin with ID " + id + " not found"));

        return new ResponseEntity<>(admin, HttpStatus.OK);
    }
    
    public Admin getByUsername(String username) {
        return adminRepo.findByAdmUsername(username);
    }


   
    public ResponseEntity<String> deleteAdmin(int id) {
        if (!adminRepo.existsById(id)) {
            throw new ResourceNotFoundException("Cannot delete. Admin with ID " + id + " not found");
        }
        adminRepo.deleteById(id);
        return new ResponseEntity<>("Admin deleted successfully", HttpStatus.OK);
    }
}



