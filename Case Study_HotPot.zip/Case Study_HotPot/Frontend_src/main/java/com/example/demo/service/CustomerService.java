package com.example.demo.service;

import com.example.demo.model.Customer;
import com.example.demo.repo.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService implements UserDetailsService {

    @Autowired
    private CustomerRepository customerRepository;

  
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Customer customer = customerRepository.findByCusUsername(username);
        if (customer == null) {
            throw new UsernameNotFoundException("Customer not found");
        }

        return new User(customer.getCusUsername(), customer.getCusPassword(), List.of());
    }

   
    public List<Customer> showCustomer() {
        return customerRepository.findAll();
    }

    public int authentication(String username, String password) {
        Customer customer = customerRepository.findByCusUsername(username);
        return (customer != null && customer.getCusPassword().equals(password)) ? 1 : 0;
    }

    public ResponseEntity<Customer> searchByCustomerId(int id) {
        Optional<Customer> customer = customerRepository.findById(id);
        return customer.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    public ResponseEntity<Customer> searchByCustomerUserName(String username) {
        Customer customer = customerRepository.findByCusUsername(username);
        return (customer != null) ? ResponseEntity.ok(customer) : ResponseEntity.notFound().build();
    }

    public String addCustomer(Customer customer) {
        customerRepository.save(customer);
        return "Customer added successfully";
    }
}

