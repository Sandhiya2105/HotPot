package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
import com.example.demo.model.Restaurants;
import com.example.demo.repo.RestaurantsRepository;
import com.example.demo.exception.ResourceNotFoundException;

@Service
public class RestaurantsService implements UserDetailsService {

    @Autowired
    private RestaurantsRepository repo;

    public String add(Restaurants r) {
        repo.save(r);
        return "Restaurant Added";
    }

    public List<Restaurants> showAll() {
        return repo.findAll();
    }

    public List<Restaurants> showByName(String name) {
        return repo.findByName(name);
    }

    public ResponseEntity<Restaurants> showByNameLocation(String name, String location) {
        Restaurants rest = repo.findByNameAndLocation(name, location);
        if (rest == null) throw new ResourceNotFoundException("Restaurant not found with given name and location");
        return ResponseEntity.ok(rest);
    }

    public ResponseEntity<Restaurants> showById(int id) {
        Restaurants rest = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Restaurant ID Not Found"));
        return ResponseEntity.ok(rest);
    }

    public List<Restaurants> showByCity(String city) {
        return repo.findByLocationIgnoreCase(city);
    }

    public String delete(int id) {
        if (!repo.existsById(id)) {
            throw new ResourceNotFoundException("Restaurant with ID " + id + " does not exist");
        }
        repo.deleteById(id);
        return "Deleted";
    }

    public Restaurants getByUsername(String username) {
        return repo.findByUsername(username);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Restaurants restaurant = repo.findByUsername(username);
        if (restaurant == null) {
            throw new UsernameNotFoundException("Restaurant not found");
        }
        return new User(restaurant.getUsername(), restaurant.getPassword(), List.of());
    }
}

