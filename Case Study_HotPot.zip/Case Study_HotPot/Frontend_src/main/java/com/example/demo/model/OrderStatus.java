package com.example.demo.model;

public enum OrderStatus {
	PENDING, ACCEPTED, DENIED
}