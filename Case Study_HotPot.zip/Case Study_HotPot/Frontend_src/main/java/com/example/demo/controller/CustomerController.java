package com.example.demo.controller;

import com.example.demo.config.JwtService;

import com.example.demo.model.AuthRequest;
import com.example.demo.model.Customer;
import com.example.demo.service.CustomerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;

    @PostMapping("/CustomerLogin")
    public String loginCustomer(@RequestBody AuthRequest request) {
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        UserDetails userDetails = customerService.loadUserByUsername(request.getUsername());
        return jwtService.generateToken(userDetails.getUsername());
    }

    @PostMapping("/addCustomer")
    public String addCustomer(@RequestBody Customer customer) {
        return customerService.addCustomer(customer);
    }

    @GetMapping("/showCustomer")
    public List<Customer> showCustomer() {
        return customerService.showCustomer();
    }

    @GetMapping("/searchCustomer/{custId}")
    public ResponseEntity<Customer> searchById(@PathVariable int custId) {
        return customerService.searchByCustomerId(custId);
    }

    @GetMapping("/searchByUserName/{userName}")
    public ResponseEntity<Customer> searchByUserName(@PathVariable String userName) {
        return customerService.searchByCustomerUserName(userName);
    }
}
