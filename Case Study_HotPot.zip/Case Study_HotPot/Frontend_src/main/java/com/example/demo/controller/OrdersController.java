package com.example.demo.controller;

import com.example.demo.model.Orders;
import org.springframework.http.MediaType;
import com.example.demo.service.OrdersService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/orders")
public class OrdersController {

    @Autowired
    private OrdersService ordersService;

    
    @PostMapping(value = "/place", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> placeOrder(@RequestBody Orders order) {
        ordersService.placeOrder(order);  
        return ResponseEntity.ok("Order placed successfully");
    }

    @GetMapping("/all")
    public List<Orders> getAllOrders() {
        return ordersService.getAllOrders();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Orders> getOrderById(@PathVariable int id) {
        return ordersService.getOrderById(id);
    }

    @GetMapping("/customer/{cusId}")
    public List<Orders> getOrdersByCustomer(@PathVariable int cusId) {
        return ordersService.getOrdersByCustomerId(cusId);
    }

    @GetMapping("/admin/{admId}")
    public List<Orders> getOrdersByAdmin(@PathVariable int admId) {
        return ordersService.getOrdersByAdminId(admId);
    }


    @PutMapping("/update/{id}")
    public Orders updateOrderStatus(@PathVariable int id, @RequestBody Orders updatedOrder) {
        return ordersService.updateOrderStatus(id, updatedOrder);
    }
    @GetMapping("/restaurant/{restId}")
    public List<Orders> getByRestaurant(@PathVariable int restId) {
        return ordersService.getOrdersByRestaurantId(restId);
    }

    @PutMapping("/restaurant/status/{ordId}")
    public String updateStatusByRestaurant(
            @PathVariable int ordId,
            @RequestParam String status) {
        return ordersService.updateStatusByRestaurant(ordId, status);
    }


    @DeleteMapping("/delete/{id}")
    public void deleteOrder(@PathVariable int id) {
        ordersService.deleteOrder(id);
    }

    @PutMapping("/decision/{id}")
    public ResponseEntity<Orders> adminDecision(
            @PathVariable int id,
            @RequestParam String status,
            @RequestParam(defaultValue = "Decision updated") String comments) {
        return ordersService.updateOrderStatus(id, status.toUpperCase(), comments);
    }
}

