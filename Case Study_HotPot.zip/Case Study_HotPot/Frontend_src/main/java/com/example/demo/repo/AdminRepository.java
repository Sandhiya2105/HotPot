package com.example.demo.repo;

import com.example.demo.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Admin, Integer> {
	 Admin findByAdmUsernameAndAdmPassword(String admUsername, String admPassword);
	    Admin findByAdmUsername(String admUsername);

}

