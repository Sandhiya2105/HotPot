package com.example.demo.model;

public enum WalSource {
	PAYTM, CREDIT_CARD, DEBIT_CARD
}
