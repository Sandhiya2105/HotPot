package com.example.demo.service;

import com.example.demo.model.OrderStatus;
import com.example.demo.model.Orders;
import com.example.demo.repo.OrdersRepository;
import com.example.demo.exception.ResourceNotFoundException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

    @Mock
    private OrdersRepository ordersRepository;

    @InjectMocks
    private OrdersService ordersService;

    private Orders order;

    @BeforeEach
    void setup() {
        order = new Orders();
        order.setOrdId(101);
        order.setCusId(1);
        order.setOrdStatus(OrderStatus.PENDING);
        order.setOrdBillamount(200.0);
        order.setOrdComments("Initial");
    }

    @Test
    void testPlaceOrder() {
        when(ordersRepository.save(order)).thenReturn(order);

        Orders result = ordersService.placeOrder(order);

        assertEquals(OrderStatus.PENDING, result.getOrdStatus());
        verify(ordersRepository, times(1)).save(order);
    }

    @Test
    void testGetAllOrders() {
        List<Orders> list = Arrays.asList(order);
        when(ordersRepository.findAll()).thenReturn(list);

        List<Orders> result = ordersService.getAllOrders();

        assertEquals(1, result.size());
        assertEquals(101, result.get(0).getOrdId());
    }

    @Test
    void testGetOrderById_Success() {
        when(ordersRepository.findById(101)).thenReturn(Optional.of(order));

        ResponseEntity<Orders> response = ordersService.getOrderById(101);

        assertEquals(101, response.getBody().getOrdId());
    }

    @Test
    void testGetOrderById_NotFound() {
        when(ordersRepository.findById(102)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            ordersService.getOrderById(102);
        });
    }

    @Test
    void testUpdateOrderStatus() {
        Orders update = new Orders();
        update.setOrdStatus(OrderStatus.ACCEPTED);
        update.setOrdComments("Approved");

        when(ordersRepository.findById(101)).thenReturn(Optional.of(order));
        when(ordersRepository.save(any(Orders.class))).thenReturn(order);

        Orders updated = ordersService.updateOrderStatus(101, update);

        assertEquals(OrderStatus.ACCEPTED, updated.getOrdStatus());
        assertEquals("Approved", updated.getOrdComments());
    }
}

