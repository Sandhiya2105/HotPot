package com.example.demo.service;

import com.example.demo.model.Customer;
import com.example.demo.repo.CustomerRepository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class CustomerServiceTest {

    @InjectMocks
    private CustomerService customerService;

    @Mock
    private CustomerRepository customerRepository;

    @Test
    public void testShowCustomer_returnsAllCustomers() {
      
        Customer c1 = new Customer(1, "Alice", "123456", "alice", "pass", "alice@email.com");
        Customer c2 = new Customer(2, "Bob", "987654", "bob", "word", "bob@email.com");
        List<Customer> mockList = Arrays.asList(c1, c2);

        when(customerRepository.findAll()).thenReturn(mockList);

      
        List<Customer> result = customerService.showCustomer();

       
        assertEquals(2, result.size());
        assertEquals("Alice", result.get(0).getCusName());
        assertEquals("Bob", result.get(1).getCusName());
    }

    @Test
    public void testSearchByCustomerId_validId() {
        Customer mockCustomer = new Customer(1, "Alice", "123456", "alice", "pass", "alice@email.com");
        when(customerRepository.findById(1)).thenReturn(Optional.of(mockCustomer));

        var response = customerService.searchByCustomerId(1);

        assertTrue(response.getStatusCode().is2xxSuccessful());
        assertEquals("Alice", response.getBody().getCusName());
    }

    @Test
    public void testSearchByCustomerUserName_validUsername() {
        Customer mockCustomer = new Customer(1, "Alice", "123456", "alice", "pass", "alice@email.com");
        when(customerRepository.findByCusUsername("alice")).thenReturn(mockCustomer);

        var response = customerService.searchByCustomerUserName("alice");

        assertTrue(response.getStatusCode().is2xxSuccessful());
        assertEquals(1, response.getBody().getCusId());
    }
    @Test
    void testAddCustomer() {
        Customer customer = new Customer(1, "John", "1234567890", "john123", "pass", "john@email.com");

        Mockito.when(customerRepository.save(customer)).thenReturn(customer);

        String result = customerService.addCustomer(customer);
        assertEquals("Customer added successfully", result);
    }
    @Test
    void testSearchByUsername() {
        Customer customer = new Customer(1, "John", "1234567890", "john123", "pass", "john@email.com");

        Mockito.when(customerRepository.findByCusUsername("john123")).thenReturn(customer);

        ResponseEntity<Customer> result = customerService.searchByCustomerUserName("john123");
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals("John", result.getBody().getCusName());
    }

}

